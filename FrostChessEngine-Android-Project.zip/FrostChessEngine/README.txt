FROST CHESS ENGINE — ANDROID PROJECT

Project Android Studio (Java + WebView), prototipe offline.
Saat ini berisi papan interaktif sederhana dan pemuat FEN. Ini BELUM memiliki Stockfish,
aturan legal lengkap, atau fitur best-move sungguhan.

CARA MEMBANGUN APK:
1. Ekstrak ZIP.
2. Buka folder FrostChessEngine di Android Studio.
3. Tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

AGAR MENJADI ENGINE SUNGGUHAN:
Tambahkan binary Stockfish yang kompatibel dengan ABI perangkat (umumnya arm64-v8a)
dan integrasikan protokol UCI melalui proses native. Pastikan mengikuti lisensi GPL
Stockfish serta menyertakan pemberitahuan dan source code sesuai ketentuannya.

Aplikasi ini ditujukan untuk analisis dan latihan, bukan bantuan tersembunyi saat pertandingan.
